from django.shortcuts import render, redirect, get_object_or_404
from django.core.files.storage import default_storage
from .models import Usuario, Bitacora, CodigoPostal
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.utils import timezone
from django.core.paginator import Paginator
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseNotAllowed, JsonResponse
from weasyprint import HTML
from django.core.files.storage import default_storage
from django.contrib.auth.decorators import login_required
from .forms import UsuarioForm
from django.urls import reverse


def signIn(request):
    if request.method == 'POST':
        correo = request.POST.get('correo')
        password = request.POST.get('pas')

        user = authenticate(request, correo=correo, password=password)

        if user is not None:
            login(request, user)
            # Registrar en bitácora
            movimiento = f"{user.nombre} inició sesión."
            Bitacora.objects.create(movimiento=movimiento, usuario=user)
            return redirect('dashboard')  # Redirige a donde quieras
        else:
            messages.error(request, 'Correo o contraseña incorrectos.')

    return render(request, 'pages/sign-in.html')

def signUp(request):
    if request.method == 'POST':
        nombre = request.POST['nombre']
        correo = request.POST['correo']
        pas = request.POST['pas']
        pas2 = request.POST['pas2']
        username = request.POST['username']
        telefono = request.POST['telefono']
        codigoP = request.POST['codigoP']
        municipio = request.POST['municipio']
        estado = request.POST['estado']
        direccion = request.POST['direccion']
        fotoPerfil = request.FILES.get('fotoPerfil')

        # Verificar que las contraseñas coincidan
        if pas != pas2:
            messages.error(request, "Las contraseñas no coinciden.")
            return render(request, 'pages/sign-up.html')

        # Verificar si el correo ya existe
        if Usuario.objects.filter(correo=correo).exists():
            messages.error(request, "El correo ya está registrado.")
            return render(request, 'pages/sign-up.html')

        # Verificar si el teléfono ya existe
        if Usuario.objects.filter(telefono=telefono).exists():
            messages.error(request, "El teléfono ya está registrado.")
            return render(request, 'pages/sign-up.html')

        # Crear el usuario
        user = Usuario.objects.create_user(
            nombre=nombre,
            correo=correo,
            password=pas,
            username=username,
            telefono=telefono,
            codigoP=codigoP,
            municipio=municipio,
            estado=estado,
            direccion=direccion
        )

        # Guardar la imagen si fue enviada
        if fotoPerfil:
            ruta_foto = default_storage.save(f'profiles/{fotoPerfil.name}', fotoPerfil)
            user.fotoPerfil = ruta_foto
            user.save()

        # Crear entrada en bitácora
        movimiento = f"Se registró {nombre} con phone {telefono}"
        Bitacora.objects.create(movimiento=movimiento, usuario=user)

        messages.success(request, "Usuario registrado correctamente.")
        return redirect('signIn')
    return render(request, 'pages/sign-up.html')

def signOut(request):
    if request.user.is_authenticated:
        
        try:
            usuario = Usuario.objects.get(correo=request.user.correo)
            movimiento = f"{usuario.nombre} cerró sesión."
            Bitacora.objects.create(movimiento=movimiento, usuario=usuario)
        except Usuario.DoesNotExist:
            pass 

    logout(request)
    return redirect('signIn')

@login_required(login_url='signIn')
def dashboard(request):
    return render(request, 'pages/dashboard.html')



@login_required(login_url='signIn')
def tables(request):
    usuarios_list = Usuario.objects.all().order_by('id_u')
    usuario_page_number = request.GET.get('usuario_page')
    usuario_paginator = Paginator(usuarios_list, 5)
    usuarios = usuario_paginator.get_page(usuario_page_number)

    bitacora_list = Bitacora.objects.all().order_by('-fecha')  # orden descendente por fecha
    bitacora_page_number = request.GET.get('bitacora_page')
    bitacora_paginator = Paginator(bitacora_list, 5)
    bitacoras = bitacora_paginator.get_page(bitacora_page_number)
    return render(request, 'pages/tables.html', {'usuarios': usuarios, 'bitacoras': bitacoras})

def export_usuarios_pdf(request):
    usuarios = Usuario.objects.all()
    html_string = render_to_string('pdf/usuarios_pdf.html', {'usuarios': usuarios})
    
    html = HTML(string=html_string)
    pdf = html.write_pdf()

    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="usuarios.pdf"'
    return response

def cambiar_estado_usuario(request, usuario_id):
    if request.method not in ['POST', 'GET']:
        return HttpResponseNotAllowed(['POST', 'GET'])

    usuario = get_object_or_404(Usuario, id_u=usuario_id)
    usuario.activo = 0 if usuario.activo == 1 else 1
    usuario.save()

    estado = "desactivó" if usuario.activo == 0 else "activó"

     # Obtener el usuario que está realizando la acción
    usuario_accion = None
    if request.user.is_authenticated:
        try:
            usuario_accion = Usuario.objects.get(correo=request.user.correo)
        except Usuario.DoesNotExist:
            usuario_accion = None

    # Crear el registro en bitácora con el usuario que hizo el cambio
    Bitacora.objects.create(
        movimiento=f"Se {estado} el usuario {usuario.nombre} (phone: {usuario.telefono})",
        usuario=usuario
    )

    return redirect('tables')  # O la vista a la que quieras regresar

def obtener_datos_cp(request):
    cp = request.GET.get('cp')
    if cp:
        datos = CodigoPostal.objects.filter(codigo_postal=cp).first()
        if datos:
            return JsonResponse({
                'municipio': datos.municipio,
                'estado': datos.estado
            })
    return JsonResponse({'error': 'No encontrado'}, status=404)

@login_required(login_url='signIn')
def profile(request, id_u):
    usuario = get_object_or_404(Usuario, pk=id_u)

    if request.method == 'POST':
        usuario.nombre = request.POST.get('nombre')
        usuario.correo = request.POST.get('correo')
        usuario.telefono = request.POST.get('telefono')
        usuario.username = request.POST.get('username')
        usuario.codigoP = request.POST.get('codigoP')
        usuario.municipio = request.POST.get('municipio')
        usuario.estado = request.POST.get('estado')
        usuario.direccion = request.POST.get('direccion')
        fotoPerfil = request.FILES.get('fotoPerfil')
        
        if fotoPerfil:
            ruta_foto = default_storage.save(f'profiles/{fotoPerfil.name}', fotoPerfil)
            usuario.fotoPerfil = ruta_foto

        usuario.save()

        messages.success(request, 'Usuario actualizado correctamente.')
        return redirect('tables')  # ✅ redirige a sí mismo

    return render(request, 'pages/profile.html', {'usuario': usuario})









