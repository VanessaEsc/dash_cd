from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.utils import timezone

class UsuarioManager(BaseUserManager):
    def create_user(self, correo, nombre, password=None, **extra_fields):
        if not correo:
            raise ValueError('El correo debe ser obligatorio')
        correo = self.normalize_email(correo)
        user = self.model(correo=correo, nombre=nombre, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, correo, nombre, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser debe tener is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser debe tener is_superuser=True.')

        return self.create_user(correo, nombre, password, **extra_fields)


class Usuario(AbstractBaseUser, PermissionsMixin):
    id_u = models.AutoField(primary_key=True, db_column='id_u')
    nombre = models.CharField(max_length=200, db_column='nombre')
    correo = models.EmailField(unique=True, max_length=200, db_column='correo')
    fotoPerfil = models.CharField(max_length=500, blank=True, null=True, db_column='fotoPerfil')
    activo = models.BooleanField(default=True, db_column='activo')
    telefono = models.CharField(max_length=20,  db_column='telefono')
    username = models.CharField(max_length=200, db_column='username')
    codigoP = models.CharField(max_length=200, db_column='codigoP')
    municipio = models.CharField(max_length=200, db_column='municipio')
    estado = models.CharField(max_length=200, db_column='estado')
    direccion = models.CharField(max_length=200, db_column='direccion')

    # Estos campos son necesarios para el admin y permisos
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    USERNAME_FIELD = 'correo'
    REQUIRED_FIELDS = ['nombre']

    objects = UsuarioManager()

    class Meta:
        db_table = 'usuarios'

    def __str__(self):
        return self.correo
    

class Bitacora(models.Model):
    id_b = models.AutoField(primary_key=True, db_column='id_b')
    movimiento = models.CharField(max_length=200, db_column='movimiento')
    fecha = models.DateTimeField(default=timezone.now)
    usuario = models.ForeignKey('Usuario', on_delete=models.CASCADE, db_column='id_u', null=True, blank=True)

    class Meta:
        db_table = 'bitacora'


class CodigoPostal(models.Model):
    id = models.AutoField(primary_key=True, db_column='id')
    codigo_postal = models.CharField(max_length=200, db_column='codigo_postal')
    asentamiento = models.CharField(max_length=200, db_column='asentamiento')
    tipo_asentamiento = models.CharField(max_length=200, db_column='tipo_asentamiento')
    municipio = models.CharField(max_length=200, db_column='municipio')
    estado = models.CharField(max_length=200, db_column='estado')

    class Meta:
        db_table = 'codigos_postales'
