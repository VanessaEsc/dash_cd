from django import forms
from .models import Usuario

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['nombre', 'correo', 'telefono', 'username', 'codigoP', 'municipio', 'estado', 'direccion', 'fotoPerfil']
        widgets = {
            'fotoPerfil': forms.TextInput(attrs={'readonly': 'readonly'}),  # si lo guardas como ruta
        }
