from django.urls import path
from . import views
from .views import export_usuarios_pdf

urlpatterns = [
    path('signIn/', views.signIn, name='signIn'),
    path('signUp/', views.signUp, name='signUp'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('profile/<int:id_u>/', views.profile, name='profile'), 
    path('tables/', views.tables, name='tables'),
    path('exportar-usuarios-pdf/', export_usuarios_pdf, name='export_usuarios_pdf'),
    path('logout/', views.signOut, name='signOut'),
    path('tables/<int:usuario_id>/cambiar_estado/', views.cambiar_estado_usuario, name='cambiar_estado_usuario'),
    path('api/cp/', views.obtener_datos_cp, name='obtener_datos_cp'),
]