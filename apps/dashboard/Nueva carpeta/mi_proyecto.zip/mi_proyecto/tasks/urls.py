from django.urls import path
from .views import tareas_por_perfil

urlpatterns = [
    path('tareas/', tareas_por_perfil, name='tareas_por_perfil'),
]