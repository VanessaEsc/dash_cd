from django.shortcuts import render
from .models import Task
from web.models import Usuario 

from django.core.paginator import Paginator

def tareas_por_perfil(request):
    perfil = request.user  # Asumiendo que tienes `request.user` vinculado a un `Profile`
    nombre_buscado = request.GET.get('buscar', '')

    tareas = Task.objects.filter(perfil=perfil, nombre__icontains=nombre_buscado)
    paginator = Paginator(tareas, 3)  # 3 por página
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'pages/tarea.html', {'page_obj': page_obj, 'buscar': nombre_buscado})
