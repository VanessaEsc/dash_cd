from django.db import models

from web.models import Usuario  # ajusta el import según dónde esté tu modelo Profile

class Task(models.Model):
    id_t = models.AutoField(primary_key=True, db_column='id_t')
    nombre = models.CharField(max_length=50, db_column='nombre')
    descripcion = models.CharField(max_length=100, db_column='descripcion')
    estatus = models.BooleanField(default=False, db_column='estatus' )  # True: EN PROCESO, False: TERMINADA
    perfil = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='tareas', db_column='perfil')

    class Meta:
        db_table = 'tasks'

    def __str__(self):
        return self.nombre
# Create your models here.
